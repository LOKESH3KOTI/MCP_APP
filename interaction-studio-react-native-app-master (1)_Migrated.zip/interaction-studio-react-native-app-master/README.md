# interaction-studio-react-native-app
This app connects a simple react native app to Salesforce Marketing Cloud Personalization and tracks events like View Screen, View item and Add to Cart
